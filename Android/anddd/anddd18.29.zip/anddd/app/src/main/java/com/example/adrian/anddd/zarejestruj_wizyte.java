package com.example.adrian.anddd;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.sql.Connection;

public class zarejestruj_wizyte extends AppCompatActivity {

    Connection Connect;
    Button UmowWizyte;
    Spinner specSpin, lekSpin;
    TextView EndowyTekst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zarejestruj_wizyte);

        UmowWizyte = findViewById(R.id.bUmowWizyte);
        specSpin = findViewById(R.id.spinerSpec);
        lekSpin = findViewById(R.id.spinerLek);
        EndowyTekst = findViewById(R.id.KoncoweTextView);

        UmowWizyte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // nowaWizyta nWizyta = new nowaWizyta;
               // nWizyta.execute("");
            }
        });

    }
}
