package com.example.adrian.anddd;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.AbstractQueue;
import java.util.ArrayList;

public class listaLekarzy extends AppCompatActivity {

    Spinner spec_spiner, wyb_spiner;
    String wybSpecjal, wybLekarz, wspec;
    //ArrayAdapter<CharSequence> adapter;
    TextView wybor;
    Connection Connect;
    PreparedStatement stmt, smtpa;
    ResultSet rs, crs;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_lekarzy);

        wybor = findViewById(R.id.ttwybor);
        wyb_spiner = findViewById(R.id.slistaLekarzy);
        spec_spiner = findViewById(R.id.slistaSpecjalistow);

        /*adapter = ArrayAdapter.createFromResource(this, R.array.Specjalizacje, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spec_spiner.setAdapter(adapter);
        spec_spiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                wybSpecjal = parent.getItemAtPosition(position).toString();

                Toast.makeText(getBaseContext(), parent.getItemAtPosition(position) + " Wybrany", Toast.LENGTH_LONG).show();
                wybor.setText(wybSpecjal);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
           }
        });*/
        //String query = "select Specjalizacja from lekarze";



        try {
            String query = "select Specjalizacja from lekarze";
            polaczenie conStr = new polaczenie();
            Connect = conStr.CONN();
            stmt = Connect.prepareStatement(query);
            rs = stmt.executeQuery();
            ArrayList<String> data = new ArrayList<String>();


            while (rs.next()) {
                String id = rs.getString("Specjalizacja");
                data.add(id);

            }
            //String[] array = data.toArray(new String[0]);
            ArrayAdapter NoCoreAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, data);
            spec_spiner.setAdapter(NoCoreAdapter);
            Connect.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


         spec_spiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                wybSpecjal = parent.getItemAtPosition(position).toString();
                Toast.makeText(getBaseContext(), "Wybrany specjalizację: " +  parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                wybor.setText(wybSpecjal);
                String name = spec_spiner.getSelectedItem().toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });


            try {
                String queray = "SELECT Imie, Nazwisko FROM `lekarze` WHERE Specjalizacja='Ginekolog'";
                polaczenie conStr = new polaczenie();
                Connect = conStr.CONN();
                smtpa = Connect.prepareStatement(queray);
                crs = smtpa.executeQuery();
                ArrayList<String> data = new ArrayList<String>();

                while (crs.next()) {
                    String idd = crs.getString("Imie");
                    String iddd = crs.getString("Nazwisko");
                    data.add(idd+" "+iddd);
                }
                ArrayAdapter CoreAdapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, data);
                wyb_spiner.setAdapter(CoreAdapter);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            wyb_spiner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    wybLekarz = parent.getItemAtPosition(position).toString();
                    Toast.makeText(getBaseContext(), "Dr " + parent.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });
        }
}






